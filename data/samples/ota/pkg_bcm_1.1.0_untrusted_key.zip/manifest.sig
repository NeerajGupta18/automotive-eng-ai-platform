{
 "key_id": "supplier-test-key",
 "alg": "ecdsa-p256-sha256",
 "sig": "MEUCIHAdTM3zlFaJK2PIk6jq+sBlQk3Wq0tJKMu8xc5paJGxAiEAzuOrhi7vzfetv7vagUsDYkpWd8bB8jms68Tpq9mGTmI="
}