{
 "key_id": "oem-ota-2026",
 "alg": "ecdsa-p256-sha256",
 "sig": "MEUCIQDCnGaL4EM1KTm5n2xCdbEJo0Ok6lswZsL8+oHib0apeAIgGex7UZ3XSiMa6jyXhg8s8A3lNRyljlkZo5KtAgeSLq8="
}