{
 "key_id": "oem-ota-2026",
 "alg": "ecdsa-p256-sha256",
 "sig": "MEYCIQD4IQEMt+8QJfMsrPtf95yDJZ3o0KnL80lFZ7vJKkxKkAIhAODxemA8SvxdBlVI7BUs8CFyopCqQwIj2UeuganHyizD"
}